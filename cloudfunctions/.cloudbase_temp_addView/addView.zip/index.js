
const cloudbase = require("@cloudbase/node-sdk");

const app = cloudbase.init({});
// 1. 获取数据库引用
const db = app.database();

const _ = db.command;

exports.main = async (event, context) => {
  const res = await db
    .collection(event.table)
    .where({
      _id: event._id
    })
    .update({
        view: _.inc(1)
    })
  return {
    res
  };
};